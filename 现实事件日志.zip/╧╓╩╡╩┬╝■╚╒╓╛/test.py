from collections import defaultdict

def format_adjacent_activities(traces):
    adjacent_activities = defaultdict(int)

    for trace in traces:
        frequency = trace[0]
        activities = trace[1]

        for i in range(len(activities) - 1):
            activity_pair = (activities[i], activities[i + 1])
            adjacent_activities[activity_pair] += frequency

    formatted_output = [[], []]
    for activity_pair, frequency in adjacent_activities.items():
        formatted_output[0].append(f"{activity_pair[0]}->{activity_pair[1]}")
        formatted_output[1].append(frequency)

    return formatted_output

# 示例的迹集合
traces = [
    [2, ['A', 'B', 'C', 'D']],
    [1, ['A', 'B', 'C', 'E']],
    [3, ['A', 'B', 'E', 'F']]
]

formatted_output = format_adjacent_activities(traces)

# 输出格式化后的相邻活动对及其频率
print(formatted_output)

